class TwoFer {
    twoFer(who = "you") {
        return `One for ${who}, one for me.`;
    }
}

module.exports = TwoFer;
