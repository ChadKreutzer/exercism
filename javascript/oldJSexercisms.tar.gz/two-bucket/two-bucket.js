module.exports = class TwoBuckets {
  constructor(capacityOne, capacityTwo, targetVolume, startingBucketName) {
    if (
      targetVolume % gcd(capacityOne, capacityTwo) ||
      targetVolume > capacityOne + capacityTwo
    )
      throw new Error('It is impossible to get that amount');

    this.targetVolume = targetVolume;
    this.goalBucket = startingBucketName;
    this.otherBucket = 0;

    this.start = new Bucket(
      startingBucketName,
      startingBucketName === 'one' ? capacityOne : capacityTwo
    );
    this.other = new Bucket(
      startingBucketName === 'one' ? 'two' : 'one',
      startingBucketName === 'one' ? capacityTwo : capacityOne
    );
  }
  moves() {
    const moveCount = findMoves(this.start, this.other, this.targetVolume);

    if (this.start.volume === this.targetVolume) {
      this.otherBucket = this.other.volume;
    }
    else {
      this.goalBucket = this.other.name;
      this.otherBucket = this.start.volume;
    }
    return moveCount;
  }
};

class Bucket {
  constructor(name, capacity) {
    this.name = name;
    this.capacity = capacity;
    this.volume = 0;
  }
  pour(target) {
    if (target instanceof Bucket === false)
      throw new Error('Not a valid target');
    if (this.volume === 0) throw new Error('This Bucket is Empty');

    if (target.capacity - target.volume < this.volume) {
      this.volume -= target.capacity - target.volume;
      target.volume = target.capacity;
    }
    else {
      target.volume += this.volume;
      this.volume = 0;
    }
  }
  empty() {
    this.volume = 0;
  }
  fill() {
    this.volume = this.capacity;
  }
}

function gcd(a, b) {
  if (b > a) a, (b = b), a;
  if (b === 0) return a;
  return gcd(b, a % b);
}

function findMoves(start, other, target) {
	let moves = 0;
	while (true) {
		if (other.volume < other.capacity) {
			start.volume ? start.pour(other) : start.fill();
			moves++;
			if (start.volume === target || other.volume === target) return moves;
		} else {
			other.empty();
			moves++;
		}
	}
}
