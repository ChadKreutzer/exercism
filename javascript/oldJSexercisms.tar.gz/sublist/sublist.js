class List {
  constructor(array = []) {
    this.array = array;
  }
  toString() {
    return this.array.join('-');
  }
  compare(list) {
    const list1 = this.toString();
    const list2 = list.toString();

    if (list2 === list1) return 'EQUAL';
    return list2.indexOf(list1) > -1 ?
      'SUBLIST' :
      list1.indexOf(list2) > -1 ? 'SUPERLIST' : 'UNEQUAL';
  }
}

module.exports = List;